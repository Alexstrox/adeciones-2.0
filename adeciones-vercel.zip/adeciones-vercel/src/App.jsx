import React, { useState, useEffect, useMemo, useCallback } from "react";
import { Plus, Trash2, Users, Ticket, Search, Download, LogOut, Pencil, X, Check, AlertCircle, ChevronRight, Utensils } from "lucide-react";
import { doc, onSnapshot, setDoc } from "firebase/firestore";
import { db } from "./firebase";

const FALLBACK_PIN = "2026";
const DEFAULT_ALLOCATION = 50;
const DATA_DOC_REF = doc(db, "adeciones", "data");

const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);

const emptyData = () => ({
  members: [],
  sales: [],
  config: { eventTitle: "Evento Gastronómico", country: "", adminPin: "" },
});

function itemsTotal(items) {
  return (items || []).reduce((sum, it) => sum + (Number(it.qty) || 0), 0);
}

function memberStats(member, sales) {
  const memberSales = sales.filter((s) => s.memberId === member.id);
  const vendidas = memberSales.reduce((sum, s) => sum + itemsTotal(s.items), 0);
  const disponibles = member.allocation - vendidas;
  return { vendidas, disponibles, numPedidos: memberSales.length };
}

function fmtDate(ts) {
  const d = new Date(ts);
  return d.toLocaleString("es", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}

/* ---------------------------------- UI atoms ---------------------------------- */

function TicketCard({ children, style, className = "" }) {
  return (
    <div className={`ticket-card ${className}`} style={style}>
      {children}
    </div>
  );
}

function Toast({ toast }) {
  if (!toast) return null;
  return (
    <div className="toast" role="status">
      {toast.type === "error" ? <AlertCircle size={16} /> : <Check size={16} />}
      <span>{toast.msg}</span>
    </div>
  );
}

function Badge({ tone, children }) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

/* ---------------------------------- Sale form ---------------------------------- */

function SaleForm({ members, sellerFixedId, initial, onCancel, onSave }) {
  const [customerName, setCustomerName] = useState(initial?.customerName || "");
  const [phone, setPhone] = useState(initial?.phone || "");
  const [items, setItems] = useState(initial?.items?.length ? initial.items : [{ dish: "", qty: 1 }]);
  const [wantsInvoice, setWantsInvoice] = useState(initial?.invoice?.wants || false);
  const [invName, setInvName] = useState(initial?.invoice?.name || "");
  const [invTaxId, setInvTaxId] = useState(initial?.invoice?.taxId || "");
  const [invAddress, setInvAddress] = useState(initial?.invoice?.address || "");
  const [sellerId, setSellerId] = useState(initial?.memberId || sellerFixedId || (members[0] && members[0].id) || "");
  const [error, setError] = useState("");

  const updateItem = (idx, field, value) => {
    setItems((prev) => prev.map((it, i) => (i === idx ? { ...it, [field]: value } : it)));
  };
  const addItem = () => setItems((prev) => [...prev, { dish: "", qty: 1 }]);
  const removeItem = (idx) => setItems((prev) => (prev.length > 1 ? prev.filter((_, i) => i !== idx) : prev));

  const handleSubmit = () => {
    if (!customerName.trim() || !phone.trim()) {
      setError("Nombre y teléfono del cliente son obligatorios.");
      return;
    }
    const cleanItems = items
      .map((it) => ({ dish: it.dish.trim(), qty: Math.max(1, Number(it.qty) || 1) }))
      .filter((it) => it.dish);
    if (cleanItems.length === 0) {
      setError("Agrega al menos un platillo.");
      return;
    }
    if (!sellerId) {
      setError("Selecciona quién realizó la venta.");
      return;
    }
    if (wantsInvoice && !invName.trim()) {
      setError("Si pide factura, ingresa el nombre o razón social.");
      return;
    }
    setError("");
    onSave({
      id: initial?.id || uid(),
      timestamp: initial?.timestamp || Date.now(),
      memberId: sellerId,
      customerName: customerName.trim(),
      phone: phone.trim(),
      items: cleanItems,
      invoice: wantsInvoice
        ? { wants: true, name: invName.trim(), taxId: invTaxId.trim(), address: invAddress.trim() }
        : { wants: false },
    });
  };

  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onCancel()}>
      <div className="modal">
        <div className="modal-header">
          <h3>{initial ? "Editar venta" : "Registrar nueva venta"}</h3>
          <button className="icon-btn" onClick={onCancel} aria-label="Cerrar"><X size={18} /></button>
        </div>

        <div className="form">
          {sellerFixedId ? (
            <div className="field">
              <label>Vendido por</label>
              <div className="static-value">{members.find((m) => m.id === sellerFixedId)?.name || "—"}</div>
            </div>
          ) : (
            <div className="field">
              <label>Vendido por</label>
              <select value={sellerId} onChange={(e) => setSellerId(e.target.value)}>
                <option value="">Selecciona un miembro</option>
                {members.map((m) => (
                  <option key={m.id} value={m.id}>{m.name}</option>
                ))}
              </select>
            </div>
          )}

          <div className="grid-2">
            <div className="field">
              <label>Nombre del cliente *</label>
              <input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Ej: María López" />
            </div>
            <div className="field">
              <label>Teléfono *</label>
              <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Ej: 9999-9999" />
            </div>
          </div>

          <div className="field">
            <label>Platillos pedidos *</label>
            {items.map((it, idx) => (
              <div key={idx} className="item-row">
                <input
                  className="dish-input"
                  value={it.dish}
                  onChange={(e) => updateItem(idx, "dish", e.target.value)}
                  placeholder="Nombre del platillo (por definir)"
                />
                <input
                  type="number"
                  min="1"
                  className="qty-input"
                  value={it.qty}
                  onChange={(e) => updateItem(idx, "qty", e.target.value)}
                />
                <button type="button" className="icon-btn" onClick={() => removeItem(idx)} aria-label="Quitar platillo">
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
            <button type="button" className="link-btn" onClick={addItem}>
              <Plus size={14} /> Agregar otro platillo
            </button>
          </div>

          <label className="checkbox-row">
            <input type="checkbox" checked={wantsInvoice} onChange={(e) => setWantsInvoice(e.target.checked)} />
            ¿El cliente desea factura?
          </label>

          {wantsInvoice && (
            <div className="grid-2">
              <div className="field">
                <label>Nombre / razón social *</label>
                <input value={invName} onChange={(e) => setInvName(e.target.value)} />
              </div>
              <div className="field">
                <label>NIT / documento fiscal</label>
                <input value={invTaxId} onChange={(e) => setInvTaxId(e.target.value)} />
              </div>
              <div className="field grid-span-2">
                <label>Dirección</label>
                <input value={invAddress} onChange={(e) => setInvAddress(e.target.value)} />
              </div>
            </div>
          )}

          {error && <div className="error-text"><AlertCircle size={14} /> {error}</div>}

          <div className="modal-actions">
            <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancelar</button>
            <button type="button" className="btn btn-primary" onClick={handleSubmit}>{initial ? "Guardar cambios" : "Registrar venta"}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Member view ---------------------------------- */

function MemberView({ data, persist, showToast, savedName, onSaveName }) {
  const [nameInput, setNameInput] = useState(savedName || "");
  const [currentMemberId, setCurrentMemberId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingSale, setEditingSale] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);

  useEffect(() => {
    if (savedName) {
      const existing = data.members.find((m) => m.name.toLowerCase() === savedName.trim().toLowerCase());
      if (existing) setCurrentMemberId(existing.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [savedName, data.members.length]);

  const currentMember = data.members.find((m) => m.id === currentMemberId);

  const handleEnter = () => {
    const trimmed = nameInput.trim();
    if (!trimmed) return;
    let member = data.members.find((m) => m.name.toLowerCase() === trimmed.toLowerCase());
    if (!member) {
      member = { id: uid(), name: trimmed, allocation: DEFAULT_ALLOCATION, createdAt: Date.now() };
      persist({ ...data, members: [...data.members, member] });
      showToast(`¡Bienvenido/a, ${trimmed}! Se te asignaron ${DEFAULT_ALLOCATION} adeciones.`);
    }
    setCurrentMemberId(member.id);
    onSaveName(trimmed);
  };

  const handleLogout = () => {
    setCurrentMemberId(null);
    setNameInput("");
    onSaveName("");
  };

  const handleSaveSale = (sale) => {
    const exists = data.sales.some((s) => s.id === sale.id);
    const newSales = exists ? data.sales.map((s) => (s.id === sale.id ? sale : s)) : [...data.sales, sale];
    persist({ ...data, sales: newSales });
    setShowForm(false);
    setEditingSale(null);
    showToast(exists ? "Venta actualizada." : "Venta registrada. ¡Gracias por vender!");
  };

  const handleDelete = (saleId) => {
    persist({ ...data, sales: data.sales.filter((s) => s.id !== saleId) });
    setConfirmDelete(null);
    showToast("Venta eliminada.");
  };

  if (!currentMember) {
    return (
      <div className="center-stage">
        <TicketCard className="gate-card">
          <div className="eyebrow">Acceso de vendedor</div>
          <h2>¿Cuál es tu nombre?</h2>
          <p className="muted">Escribe tu nombre para ver tus adeciones o unirte al grupo de venta.</p>
          <div className="form">
            <input
              autoFocus
              list="member-names"
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleEnter()}
              placeholder="Ej: Ana Martínez"
            />
            <datalist id="member-names">
              {data.members.map((m) => <option key={m.id} value={m.name} />)}
            </datalist>
            <button type="button" className="btn btn-primary btn-block" onClick={handleEnter}>
              Entrar <ChevronRight size={16} />
            </button>
          </div>
        </TicketCard>
      </div>
    );
  }

  const { vendidas, disponibles } = memberStats(currentMember, data.sales);
  const pct = Math.min(100, Math.round((vendidas / currentMember.allocation) * 100) || 0);
  const mySales = data.sales
    .filter((s) => s.memberId === currentMember.id)
    .sort((a, b) => b.timestamp - a.timestamp);

  return (
    <div className="stack">
      <TicketCard className="stat-card">
        <div className="stat-card-top">
          <div>
            <div className="eyebrow">Tu boleto de vendedor</div>
            <h2>{currentMember.name}</h2>
          </div>
          <button className="link-btn" onClick={handleLogout}><LogOut size={14} /> Cambiar</button>
        </div>
        <div className="progress-track">
          <div className="progress-fill" style={{ width: `${pct}%` }} />
        </div>
        <div className="stat-row">
          <div className="stat-box">
            <span className="stat-num">{currentMember.allocation}</span>
            <span className="stat-label">Asignadas</span>
          </div>
          <div className="stat-box">
            <span className="stat-num" style={{ color: "var(--brick)" }}>{vendidas}</span>
            <span className="stat-label">Vendidas</span>
          </div>
          <div className="stat-box">
            <span className="stat-num" style={{ color: disponibles <= 0 ? "var(--brick)" : "var(--teal)" }}>
              {disponibles}
            </span>
            <span className="stat-label">Disponibles</span>
          </div>
        </div>
        {disponibles <= 0 && (
          <div className="warn-banner">
            <AlertCircle size={14} /> Ya vendiste todas tus adeciones. Avísale a un líder si necesitas más.
          </div>
        )}
        <button className="btn btn-primary btn-block" onClick={() => setShowForm(true)}>
          <Plus size={16} /> Registrar nueva venta
        </button>
      </TicketCard>

      <div className="section-title"><Ticket size={16} /> Mis ventas ({mySales.length})</div>

      {mySales.length === 0 ? (
        <p className="muted empty-note">Todavía no registras ventas. ¡Anímate a vender tu primera adeción!</p>
      ) : (
        <div className="sales-list">
          {mySales.map((s) => (
            <div key={s.id} className="sale-row">
              <div className="sale-main">
                <strong>{s.customerName}</strong>
                <span className="muted"> · {s.phone}</span>
                <div className="dish-tags">
                  {s.items.map((it, i) => (
                    <span key={i} className="dish-tag">{it.dish} ×{it.qty}</span>
                  ))}
                </div>
              </div>
              <div className="sale-side">
                {s.invoice?.wants && <Badge tone="teal">Factura</Badge>}
                <span className="muted small">{fmtDate(s.timestamp)}</span>
                <button className="icon-btn" onClick={() => setEditingSale(s)} aria-label="Editar"><Pencil size={14} /></button>
                <button className="icon-btn" onClick={() => setConfirmDelete(s.id)} aria-label="Eliminar"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <SaleForm
          members={data.members}
          sellerFixedId={currentMember.id}
          onCancel={() => setShowForm(false)}
          onSave={handleSaveSale}
        />
      )}
      {editingSale && (
        <SaleForm
          members={data.members}
          sellerFixedId={currentMember.id}
          initial={editingSale}
          onCancel={() => setEditingSale(null)}
          onSave={handleSaveSale}
        />
      )}
      {confirmDelete && (
        <ConfirmDialog
          message="¿Eliminar esta venta? Esta acción no se puede deshacer."
          onCancel={() => setConfirmDelete(null)}
          onConfirm={() => handleDelete(confirmDelete)}
        />
      )}
    </div>
  );
}

function ConfirmDialog({ message, onCancel, onConfirm }) {
  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onCancel()}>
      <div className="modal small">
        <p>{message}</p>
        <div className="modal-actions">
          <button className="btn btn-ghost" onClick={onCancel}>Cancelar</button>
          <button className="btn btn-danger" onClick={onConfirm}>Eliminar</button>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Admin view ---------------------------------- */

function AdminView({ data, persist, showToast }) {
  const [authed, setAuthed] = useState(false);
  const [pin, setPin] = useState("");
  const [pinError, setPinError] = useState("");
  const [search, setSearch] = useState("");
  const [newMemberName, setNewMemberName] = useState("");
  const [newMemberAlloc, setNewMemberAlloc] = useState(DEFAULT_ALLOCATION);
  const [showAddSale, setShowAddSale] = useState(false);
  const [editingSale, setEditingSale] = useState(null);
  const [confirmDeleteSale, setConfirmDeleteSale] = useState(null);
  const [confirmDeleteMember, setConfirmDeleteMember] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [eventTitleDraft, setEventTitleDraft] = useState(data.config.eventTitle);
  const [countryDraft, setCountryDraft] = useState(data.config.country);
  const [pinDraft, setPinDraft] = useState(data.config.adminPin);

  const effectivePin = data.config.adminPin || FALLBACK_PIN;

  const dishSummary = useMemo(() => {
    const map = {};
    data.sales.forEach((s) => s.items.forEach((it) => { map[it.dish] = (map[it.dish] || 0) + it.qty; }));
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [data.sales]);

  const filteredSales = useMemo(() => {
    const q = search.trim().toLowerCase();
    let list = [...data.sales].sort((a, b) => b.timestamp - a.timestamp);
    if (!q) return list;
    return list.filter((s) => {
      const member = data.members.find((m) => m.id === s.memberId);
      return (
        s.customerName.toLowerCase().includes(q) ||
        s.phone.toLowerCase().includes(q) ||
        (member && member.name.toLowerCase().includes(q)) ||
        s.items.some((it) => it.dish.toLowerCase().includes(q))
      );
    });
  }, [data.sales, data.members, search]);

  const handlePinSubmit = () => {
    if (pin === effectivePin) {
      setAuthed(true);
      setPinError("");
    } else {
      setPinError("Código incorrecto.");
    }
  };

  if (!authed) {
    return (
      <div className="center-stage">
        <TicketCard className="gate-card">
          <div className="eyebrow">Panel administrativo</div>
          <h2>Acceso restringido</h2>
          <p className="muted">Solo tesorería y líderes de grupo. Ingresa el código de acceso.</p>
          <div className="form">
            <input
              autoFocus
              type="password"
              inputMode="numeric"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handlePinSubmit()}
              placeholder="Código de acceso"
            />
            {pinError && <div className="error-text"><AlertCircle size={14} /> {pinError}</div>}
            <button type="button" className="btn btn-primary btn-block" onClick={handlePinSubmit}>Entrar</button>
          </div>
          {!data.config.adminPin && <p className="muted small">Código por defecto: {FALLBACK_PIN} (cámbialo en Ajustes al entrar).</p>}
        </TicketCard>
      </div>
    );
  }

  const totalAsignadas = data.members.reduce((s, m) => s + m.allocation, 0);
  const totalVendidas = data.sales.reduce((s, sale) => s + itemsTotal(sale.items), 0);
  const totalDisponibles = totalAsignadas - totalVendidas;

  const updateAllocation = (memberId, value) => {
    const alloc = Math.max(0, Number(value) || 0);
    persist({ ...data, members: data.members.map((m) => (m.id === memberId ? { ...m, allocation: alloc } : m)) });
  };

  const handleAddMember = () => {
    const trimmed = newMemberName.trim();
    if (!trimmed) return;
    if (data.members.some((m) => m.name.toLowerCase() === trimmed.toLowerCase())) {
      showToast("Ya existe un miembro con ese nombre.", "error");
      return;
    }
    const member = { id: uid(), name: trimmed, allocation: Math.max(0, Number(newMemberAlloc) || 0), createdAt: Date.now() };
    persist({ ...data, members: [...data.members, member] });
    setNewMemberName("");
    setNewMemberAlloc(DEFAULT_ALLOCATION);
    showToast(`Miembro "${trimmed}" agregado.`);
  };

  const handleDeleteMember = (memberId) => {
    persist({ ...data, members: data.members.filter((m) => m.id !== memberId) });
    setConfirmDeleteMember(null);
    showToast("Miembro eliminado.");
  };

  const handleSaveSale = (sale) => {
    const exists = data.sales.some((s) => s.id === sale.id);
    const newSales = exists ? data.sales.map((s) => (s.id === sale.id ? sale : s)) : [...data.sales, sale];
    persist({ ...data, sales: newSales });
    setShowAddSale(false);
    setEditingSale(null);
    showToast(exists ? "Venta actualizada." : "Venta agregada.");
  };

  const handleDeleteSale = (saleId) => {
    persist({ ...data, sales: data.sales.filter((s) => s.id !== saleId) });
    setConfirmDeleteSale(null);
    showToast("Venta eliminada.");
  };

  const saveSettings = () => {
    persist({
      ...data,
      config: { ...data.config, eventTitle: eventTitleDraft.trim() || "Evento Gastronómico", country: countryDraft.trim(), adminPin: pinDraft.trim() },
    });
    setShowSettings(false);
    showToast("Ajustes guardados.");
  };

  const exportCSV = () => {
    const header = ["Fecha", "Cliente", "Telefono", "Platillos", "Boletos", "Factura", "Nombre factura", "NIT", "Direccion", "Vendido por"];
    const rows = filteredSales.map((s) => {
      const member = data.members.find((m) => m.id === s.memberId);
      return [
        new Date(s.timestamp).toLocaleString("es"),
        s.customerName,
        s.phone,
        s.items.map((it) => `${it.dish} x${it.qty}`).join(" | "),
        itemsTotal(s.items),
        s.invoice?.wants ? "Si" : "No",
        s.invoice?.name || "",
        s.invoice?.taxId || "",
        s.invoice?.address || "",
        member ? member.name : "",
      ];
    });
    const csv = [header, ...rows]
      .map((r) => r.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "ventas-adeciones.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="stack">
      <div className="admin-top">
        <div className="summary-grid">
          <SummaryBox label="Miembros" value={data.members.length} icon={<Users size={16} />} />
          <SummaryBox label="Asignadas" value={totalAsignadas} icon={<Ticket size={16} />} />
          <SummaryBox label="Vendidas" value={totalVendidas} tone="brick" />
          <SummaryBox label="Disponibles" value={totalDisponibles} tone="teal" />
        </div>
        <div className="admin-actions">
          <button className="btn btn-ghost" onClick={() => setShowSettings(true)}>Ajustes</button>
          <button className="btn btn-ghost" onClick={exportCSV}><Download size={14} /> Exportar CSV</button>
          <button className="btn btn-primary" onClick={() => setShowAddSale(true)}><Plus size={14} /> Agregar venta</button>
        </div>
      </div>

      <div className="section-title"><Users size={16} /> Miembros del grupo</div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>Nombre</th><th>Asignadas</th><th>Vendidas</th><th>Disponibles</th><th>Estado</th><th></th></tr>
          </thead>
          <tbody>
            {data.members.length === 0 && (
              <tr><td colSpan={6} className="muted empty-cell">Aún no hay miembros registrados.</td></tr>
            )}
            {data.members
              .slice()
              .sort((a, b) => a.name.localeCompare(b.name))
              .map((m) => {
                const { vendidas, disponibles, numPedidos } = memberStats(m, data.sales);
                let tone = "neutral", label = "En progreso";
                if (numPedidos === 0) { tone = "muted"; label = "Sin vender aún"; }
                else if (disponibles <= 0) { tone = "brick"; label = "Necesita más adeciones"; }
                else if (disponibles <= Math.max(5, m.allocation * 0.1)) { tone = "marigold"; label = "Casi agotado"; }
                else { tone = "teal"; label = "Vendiendo"; }
                return (
                  <tr key={m.id}>
                    <td><strong>{m.name}</strong></td>
                    <td>
                      <input
                        type="number"
                        min="0"
                        className="alloc-input"
                        value={m.allocation}
                        onChange={(e) => updateAllocation(m.id, e.target.value)}
                      />
                    </td>
                    <td>{vendidas}</td>
                    <td style={{ color: disponibles <= 0 ? "var(--brick)" : "inherit" }}>{disponibles}</td>
                    <td><Badge tone={tone}>{label}</Badge></td>
                    <td><button className="icon-btn" onClick={() => setConfirmDeleteMember(m.id)} aria-label="Eliminar miembro"><Trash2 size={14} /></button></td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </div>

      <div className="inline-form">
        <input
          value={newMemberName}
          onChange={(e) => setNewMemberName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAddMember()}
          placeholder="Nombre del nuevo miembro"
        />
        <input type="number" min="0" value={newMemberAlloc} onChange={(e) => setNewMemberAlloc(e.target.value)} className="alloc-input" />
        <button type="button" className="btn btn-secondary" onClick={handleAddMember}><Plus size={14} /> Agregar miembro</button>
      </div>

      {dishSummary.length > 0 && (
        <>
          <div className="section-title"><Utensils size={16} /> Resumen por platillo</div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Platillo</th><th>Cantidad total</th></tr></thead>
              <tbody>
                {dishSummary.map(([dish, qty]) => (
                  <tr key={dish}><td>{dish}</td><td><strong>{qty}</strong></td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      <div className="section-title-row">
        <div className="section-title"><Ticket size={16} /> Ventas / clientes ({filteredSales.length})</div>
        <div className="search-box">
          <Search size={14} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar cliente, teléfono, vendedor o platillo…" />
        </div>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>Fecha</th><th>Cliente</th><th>Teléfono</th><th>Platillos</th><th>Boletos</th><th>Factura</th><th>Vendido por</th><th></th></tr>
          </thead>
          <tbody>
            {filteredSales.length === 0 && (
              <tr><td colSpan={8} className="muted empty-cell">No hay ventas que coincidan.</td></tr>
            )}
            {filteredSales.map((s) => {
              const member = data.members.find((m) => m.id === s.memberId);
              return (
                <tr key={s.id}>
                  <td className="mono small">{fmtDate(s.timestamp)}</td>
                  <td>{s.customerName}</td>
                  <td className="mono small">{s.phone}</td>
                  <td>
                    <div className="dish-tags">
                      {s.items.map((it, i) => <span key={i} className="dish-tag">{it.dish} ×{it.qty}</span>)}
                    </div>
                  </td>
                  <td className="mono"><strong>{itemsTotal(s.items)}</strong></td>
                  <td>{s.invoice?.wants ? <Badge tone="teal">Sí</Badge> : <span className="muted">No</span>}</td>
                  <td>{member ? member.name : <span className="muted">—</span>}</td>
                  <td className="row-actions">
                    <button className="icon-btn" onClick={() => setEditingSale(s)} aria-label="Editar"><Pencil size={14} /></button>
                    <button className="icon-btn" onClick={() => setConfirmDeleteSale(s.id)} aria-label="Eliminar"><Trash2 size={14} /></button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showAddSale && (
        <SaleForm members={data.members} onCancel={() => setShowAddSale(false)} onSave={handleSaveSale} />
      )}
      {editingSale && (
        <SaleForm members={data.members} initial={editingSale} onCancel={() => setEditingSale(null)} onSave={handleSaveSale} />
      )}
      {confirmDeleteSale && (
        <ConfirmDialog message="¿Eliminar esta venta?" onCancel={() => setConfirmDeleteSale(null)} onConfirm={() => handleDeleteSale(confirmDeleteSale)} />
      )}
      {confirmDeleteMember && (
        <ConfirmDialog
          message="¿Eliminar este miembro? Sus ventas registradas se conservarán pero quedarán sin vendedor asignado visible."
          onCancel={() => setConfirmDeleteMember(null)}
          onConfirm={() => handleDeleteMember(confirmDeleteMember)}
        />
      )}
      {showSettings && (
        <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setShowSettings(false)}>
          <div className="modal">
            <div className="modal-header">
              <h3>Ajustes del evento</h3>
              <button className="icon-btn" onClick={() => setShowSettings(false)}><X size={18} /></button>
            </div>
            <div className="form">
              <div className="field">
                <label>Nombre del evento</label>
                <input value={eventTitleDraft} onChange={(e) => setEventTitleDraft(e.target.value)} />
              </div>
              <div className="field">
                <label>País (cuando se defina)</label>
                <input value={countryDraft} onChange={(e) => setCountryDraft(e.target.value)} placeholder="Por definir" />
              </div>
              <div className="field">
                <label>Código de acceso administrativo</label>
                <input value={pinDraft} onChange={(e) => setPinDraft(e.target.value)} placeholder={`Por defecto: ${FALLBACK_PIN}`} />
              </div>
              <div className="modal-actions">
                <button className="btn btn-ghost" onClick={() => setShowSettings(false)}>Cancelar</button>
                <button className="btn btn-primary" onClick={saveSettings}>Guardar</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SummaryBox({ label, value, tone, icon }) {
  return (
    <div className={`summary-box ${tone ? `tone-${tone}` : ""}`}>
      {icon}
      <span className="summary-num">{value}</span>
      <span className="summary-label">{label}</span>
    </div>
  );
}

/* ---------------------------------- Root App ---------------------------------- */

export default function App() {
  const [data, setData] = useState(emptyData());
  const [loaded, setLoaded] = useState(false);
  const [role, setRole] = useState(null);
  const [toast, setToast] = useState(null);
  const [savedName, setSavedName] = useState("");

  const showToast = useCallback((msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3200);
  }, []);

  useEffect(() => {
    const unsubscribe = onSnapshot(
      DATA_DOC_REF,
      (snap) => {
        if (snap.exists()) {
          const parsed = snap.data();
          setData({ ...emptyData(), ...parsed, config: { ...emptyData().config, ...(parsed.config || {}) } });
        }
        setLoaded(true);
      },
      (err) => {
        console.error(err);
        showToast("No se pudo conectar con la base de datos. Revisa la configuración de Firebase.", "error");
        setLoaded(true);
      }
    );
    try {
      const mine = localStorage.getItem("mi-nombre-vendedor");
      if (mine) setSavedName(mine);
    } catch (e) {
      // localStorage no disponible (modo privado, etc.) — no es crítico
    }
    return () => unsubscribe();
  }, [showToast]);

  const persist = useCallback(async (newData) => {
    setData(newData);
    try {
      await setDoc(DATA_DOC_REF, newData);
    } catch (e) {
      console.error(e);
      showToast("Error al guardar los datos.", "error");
    }
  }, [showToast]);

  const onSaveName = useCallback((name) => {
    setSavedName(name);
    try {
      localStorage.setItem("mi-nombre-vendedor", name);
    } catch (e) {
      // no es crítico
    }
  }, []);

  if (!loaded) {
    return (
      <div className="app-shell">
        <style>{globalStyles}</style>
        <div className="center-stage"><p className="muted">Cargando…</p></div>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <style>{globalStyles}</style>
      <Toast toast={toast} />

      <header className="app-header">
        <div className="brand" onClick={() => setRole(null)} role="button" tabIndex={0}>
          <div className="brand-mark"><Ticket size={18} /></div>
          <div>
            <div className="brand-title">{data.config.eventTitle}</div>
            <div className="brand-sub">{data.config.country ? `Cocina de ${data.config.country}` : "País por definir"} · Venta de adeciones</div>
          </div>
        </div>
        {role && (
          <nav className="role-nav">
            <button className={role === "member" ? "nav-btn active" : "nav-btn"} onClick={() => setRole("member")}>Vendedor/a</button>
            <button className={role === "admin" ? "nav-btn active" : "nav-btn"} onClick={() => setRole("admin")}>Administración</button>
          </nav>
        )}
      </header>

      <main className="app-main">
        {!role && (
          <div className="landing">
            <TicketCard className="hero-ticket">
              <div className="eyebrow">Boleto de adeción · versión beta</div>
              <h1>{data.config.eventTitle}</h1>
              <p className="muted">
                Vendé reservaciones de comida sin imprimir un solo boleto. Cada miembro lleva su propio conteo,
                y tesorería ve todo el avance en tiempo real.
              </p>
              <div className="hero-stats">
                <div><span className="stat-num">{data.members.length}</span><span className="stat-label">vendedores</span></div>
                <div><span className="stat-num">{data.sales.reduce((s, x) => s + itemsTotal(x.items), 0)}</span><span className="stat-label">adeciones vendidas</span></div>
                <div><span className="stat-num">{data.sales.length}</span><span className="stat-label">clientes</span></div>
              </div>
            </TicketCard>

            <div className="role-cards">
              <button className="role-card" onClick={() => setRole("member")}>
                <Ticket size={22} />
                <h3>Soy vendedor/a</h3>
                <p>Registra tus ventas y mira cuántas adeciones te quedan.</p>
                <span className="role-card-cta">Entrar <ChevronRight size={16} /></span>
              </button>
              <button className="role-card" onClick={() => setRole("admin")}>
                <Users size={22} />
                <h3>Administración</h3>
                <p>Tesorería y líderes: seguimiento de todas las ventas.</p>
                <span className="role-card-cta">Entrar <ChevronRight size={16} /></span>
              </button>
            </div>
          </div>
        )}

        {role === "member" && (
          <MemberView data={data} persist={persist} showToast={showToast} savedName={savedName} onSaveName={onSaveName} />
        )}
        {role === "admin" && <AdminView data={data} persist={persist} showToast={showToast} />}
      </main>

      <footer className="app-footer">
        Versión beta — cuando definan país y menú, se pueden ajustar los platillos y detalles finales.
      </footer>
    </div>
  );
}

/* ---------------------------------- Styles ---------------------------------- */

const globalStyles = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap');

.app-shell {
  --ink: #22201b;
  --page-bg: #171512;
  --paper: #f1e4c8;
  --paper-soft: #e7d8b6;
  --marigold: #e3a23c;
  --brick: #c1432b;
  --teal: #3f7a63;
  --line: rgba(34,32,27,0.14);

  min-height: 100%;
  background: var(--page-bg);
  background-image:
    radial-gradient(circle at 15% 10%, rgba(227,162,60,0.08), transparent 40%),
    radial-gradient(circle at 85% 85%, rgba(63,122,99,0.08), transparent 40%);
  color: var(--paper);
  font-family: 'Inter', sans-serif;
  padding-bottom: 40px;
}

.app-shell * { box-sizing: border-box; }

.app-header {
  display: flex; align-items: center; justify-content: space-between;
  flex-wrap: wrap; gap: 12px;
  padding: 18px 24px; border-bottom: 1px dashed rgba(241,228,200,0.25);
}
.brand { display: flex; align-items: center; gap: 10px; cursor: pointer; }
.brand-mark {
  width: 36px; height: 36px; border-radius: 8px; background: var(--marigold); color: var(--ink);
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.brand-title { font-family: 'Fraunces', serif; font-weight: 700; font-size: 18px; letter-spacing: 0.2px; }
.brand-sub { font-size: 12px; color: rgba(241,228,200,0.6); }

.role-nav { display: flex; gap: 6px; background: rgba(241,228,200,0.08); padding: 4px; border-radius: 10px; }
.nav-btn {
  border: none; background: transparent; color: rgba(241,228,200,0.7); padding: 7px 14px;
  border-radius: 7px; font-size: 13px; font-weight: 500; cursor: pointer; font-family: inherit;
}
.nav-btn.active { background: var(--marigold); color: var(--ink); }

.app-main { max-width: 980px; margin: 0 auto; padding: 28px 20px 10px; }
.app-footer { text-align: center; font-size: 12px; color: rgba(241,228,200,0.4); padding: 24px 20px 4px; }

.landing { display: flex; flex-direction: column; gap: 22px; }

.ticket-card {
  position: relative;
  background: var(--paper);
  color: var(--ink);
  border-radius: 10px;
  padding: 24px;
  box-shadow: 0 18px 40px -20px rgba(0,0,0,0.55);
}
.ticket-card::before, .ticket-card::after {
  content: ''; position: absolute; top: 50%; width: 22px; height: 22px;
  background: var(--page-bg); border-radius: 50%; transform: translateY(-50%);
}
.ticket-card::before { left: -11px; }
.ticket-card::after { right: -11px; }

.hero-ticket { padding: 34px 30px; }
.eyebrow {
  font-family: 'IBM Plex Mono', monospace; text-transform: uppercase; letter-spacing: 1.5px;
  font-size: 11px; color: var(--brick); margin-bottom: 8px;
}
.hero-ticket h1 { font-family: 'Fraunces', serif; font-size: clamp(28px, 4vw, 42px); margin: 0 0 12px; line-height: 1.1; }
.hero-ticket p { max-width: 560px; margin: 0 0 20px; line-height: 1.5; }
.hero-stats { display: flex; gap: 28px; flex-wrap: wrap; border-top: 1px dashed var(--line); padding-top: 16px; }
.hero-stats > div { display: flex; flex-direction: column; }
.hero-stats .stat-num { font-family: 'IBM Plex Mono', monospace; font-size: 26px; font-weight: 500; }
.hero-stats .stat-label { font-size: 12px; opacity: 0.65; }

.role-cards { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
@media (max-width: 640px) { .role-cards { grid-template-columns: 1fr; } }
.role-card {
  background: rgba(241,228,200,0.06); border: 1px solid rgba(241,228,200,0.16);
  border-radius: 12px; padding: 22px; text-align: left; cursor: pointer; color: var(--paper);
  font-family: inherit; transition: transform 0.15s ease, background 0.15s ease;
}
.role-card:hover { background: rgba(241,228,200,0.1); transform: translateY(-2px); }
.role-card h3 { font-family: 'Fraunces', serif; font-size: 19px; margin: 10px 0 6px; }
.role-card p { font-size: 13px; opacity: 0.7; margin: 0 0 14px; line-height: 1.4; }
.role-card-cta { display: inline-flex; align-items: center; gap: 4px; color: var(--marigold); font-size: 13px; font-weight: 600; }

.center-stage { display: flex; justify-content: center; padding: 40px 10px; }
.gate-card { width: 100%; max-width: 420px; }
.gate-card h2 { font-family: 'Fraunces', serif; font-size: 24px; margin: 4px 0 6px; }
.muted { color: rgba(34,32,27,0.6); font-size: 14px; }
.app-shell .muted { color: rgba(241,228,200,0.55); }
.gate-card .muted { color: rgba(34,32,27,0.6); }
.small { font-size: 12px; }

.form { display: flex; flex-direction: column; gap: 14px; margin-top: 14px; }
.field { display: flex; flex-direction: column; gap: 5px; }
.field label { font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.4px; opacity: 0.65; }
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.grid-span-2 { grid-column: span 2; }
@media (max-width: 480px) { .grid-2 { grid-template-columns: 1fr; } .grid-span-2 { grid-column: span 1; } }

input, select {
  font-family: inherit; font-size: 14px; padding: 10px 12px; border-radius: 8px;
  border: 1px solid rgba(34,32,27,0.2); background: #fffdf8; color: var(--ink);
}
input:focus, select:focus, button:focus-visible {
  outline: 2px solid var(--marigold); outline-offset: 1px;
}
.static-value { padding: 10px 12px; background: rgba(34,32,27,0.06); border-radius: 8px; font-weight: 600; }

.btn {
  font-family: inherit; font-size: 14px; font-weight: 600; padding: 10px 16px; border-radius: 8px;
  border: none; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 6px;
}
.btn-primary { background: var(--brick); color: #fff8ee; }
.btn-primary:hover { background: #a83a26; }
.btn-secondary { background: var(--marigold); color: var(--ink); }
.btn-ghost { background: transparent; border: 1px solid rgba(241,228,200,0.3); color: var(--paper); }
.gate-card .btn-ghost, .modal .btn-ghost { border-color: rgba(34,32,27,0.25); color: var(--ink); }
.btn-danger { background: var(--brick); color: #fff8ee; }
.btn-block { width: 100%; }

.link-btn {
  background: none; border: none; color: var(--brick); font-size: 13px; font-weight: 600;
  display: inline-flex; align-items: center; gap: 4px; cursor: pointer; padding: 4px 0; font-family: inherit;
}

.icon-btn {
  background: none; border: none; color: inherit; opacity: 0.6; cursor: pointer; padding: 4px; border-radius: 6px;
}
.icon-btn:hover { opacity: 1; background: rgba(0,0,0,0.06); }

.stack { display: flex; flex-direction: column; gap: 20px; }

.stat-card { max-width: 480px; }
.stat-card-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 14px; }
.stat-card-top h2 { font-family: 'Fraunces', serif; font-size: 22px; margin: 2px 0 0; }
.progress-track { height: 8px; background: rgba(34,32,27,0.12); border-radius: 6px; overflow: hidden; margin-bottom: 16px; }
.progress-fill { height: 100%; background: linear-gradient(90deg, var(--marigold), var(--brick)); }
.stat-row { display: flex; gap: 10px; margin-bottom: 16px; }
.stat-box { flex: 1; text-align: center; background: rgba(34,32,27,0.05); border-radius: 8px; padding: 10px 6px; display: flex; flex-direction: column; }
.stat-num { font-family: 'IBM Plex Mono', monospace; font-size: 22px; font-weight: 600; }
.stat-label { font-size: 11px; opacity: 0.6; text-transform: uppercase; letter-spacing: 0.4px; }
.warn-banner {
  display: flex; align-items: center; gap: 6px; background: rgba(193,67,43,0.12); color: var(--brick);
  padding: 8px 10px; border-radius: 8px; font-size: 12.5px; margin-bottom: 14px;
}

.section-title { display: flex; align-items: center; gap: 6px; font-family: 'Fraunces', serif; font-size: 17px; margin-top: 6px; }
.section-title-row { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }

.empty-note { padding: 14px 0; }
.sales-list { display: flex; flex-direction: column; gap: 8px; }
.sale-row {
  background: rgba(241,228,200,0.06); border: 1px solid rgba(241,228,200,0.14); border-radius: 10px;
  padding: 12px 14px; display: flex; justify-content: space-between; gap: 12px; flex-wrap: wrap;
}
.sale-main { flex: 1; min-width: 200px; }
.dish-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; }
.dish-tag {
  font-family: 'IBM Plex Mono', monospace; font-size: 11.5px; background: rgba(227,162,60,0.16); color: var(--marigold);
  padding: 3px 8px; border-radius: 20px;
}
.sale-side { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }

.badge { font-size: 11px; font-weight: 600; padding: 3px 9px; border-radius: 20px; display: inline-block; }
.badge-teal { background: rgba(63,122,99,0.18); color: #6fbb9a; }
.badge-brick { background: rgba(193,67,43,0.18); color: #e17a63; }
.badge-marigold { background: rgba(227,162,60,0.2); color: var(--marigold); }
.badge-muted { background: rgba(241,228,200,0.1); color: rgba(241,228,200,0.55); }
.badge-neutral { background: rgba(241,228,200,0.12); color: rgba(241,228,200,0.75); }

.admin-top { display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; }
.summary-grid { display: grid; grid-template-columns: repeat(4, minmax(90px,1fr)); gap: 10px; flex: 1; }
@media (max-width: 640px) { .summary-grid { grid-template-columns: repeat(2, 1fr); } }
.summary-box {
  background: rgba(241,228,200,0.07); border: 1px solid rgba(241,228,200,0.15); border-radius: 10px;
  padding: 12px; display: flex; flex-direction: column; gap: 2px; align-items: flex-start;
}
.summary-num { font-family: 'IBM Plex Mono', monospace; font-size: 22px; font-weight: 600; }
.summary-label { font-size: 11px; opacity: 0.6; text-transform: uppercase; letter-spacing: 0.4px; }
.tone-brick .summary-num { color: #e17a63; }
.tone-teal .summary-num { color: #6fbb9a; }
.admin-actions { display: flex; gap: 8px; flex-wrap: wrap; }

.table-wrap { overflow-x: auto; border: 1px solid rgba(241,228,200,0.14); border-radius: 10px; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
thead th {
  text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 0.4px; opacity: 0.6;
  padding: 10px 12px; border-bottom: 1px solid rgba(241,228,200,0.14); white-space: nowrap;
}
tbody td { padding: 10px 12px; border-bottom: 1px solid rgba(241,228,200,0.08); vertical-align: top; }
tbody tr:last-child td { border-bottom: none; }
.empty-cell { text-align: center; padding: 22px; }
.mono { font-family: 'IBM Plex Mono', monospace; }
.alloc-input { width: 72px; padding: 6px 8px; }
.row-actions { display: flex; gap: 4px; white-space: nowrap; }

.inline-form { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
.inline-form input:first-child { flex: 1; min-width: 180px; }

.item-row { display: flex; gap: 8px; align-items: center; margin-bottom: 6px; }
.dish-input { flex: 1; }
.qty-input { width: 64px; }
.checkbox-row { display: flex; align-items: center; gap: 8px; font-size: 14px; cursor: pointer; }
.checkbox-row input { width: 16px; height: 16px; }

.error-text { display: flex; align-items: center; gap: 6px; color: var(--brick); font-size: 13px; }

.modal-backdrop {
  position: fixed; inset: 0; background: rgba(10,9,7,0.6); display: flex; align-items: center; justify-content: center;
  padding: 16px; z-index: 50; backdrop-filter: blur(2px);
}
.modal {
  background: #fffdf8; color: var(--ink); border-radius: 14px; padding: 22px; width: 100%; max-width: 520px;
  max-height: 90vh; overflow-y: auto; box-shadow: 0 30px 60px rgba(0,0,0,0.4);
}
.modal.small { max-width: 380px; }
.modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
.modal-header h3 { font-family: 'Fraunces', serif; font-size: 19px; margin: 0; }
.modal-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 6px; }

.toast {
  position: fixed; top: 16px; left: 50%; transform: translateX(-50%); z-index: 60;
  background: var(--ink); color: var(--paper); padding: 10px 16px; border-radius: 30px;
  display: flex; align-items: center; gap: 8px; font-size: 13px; box-shadow: 0 10px 30px rgba(0,0,0,0.35);
}
`;
