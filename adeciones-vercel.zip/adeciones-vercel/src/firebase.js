// ============================================================
// CONFIGURACIÓN DE FIREBASE
// ============================================================
// Pegá acá las claves de TU proyecto de Firebase (paso a paso
// en el README.md, sección "1. Crear el proyecto en Firebase").
//
// Estas claves no son secretas: Firebase está diseñado para que
// vayan directo en el código del lado del cliente. Lo que protege
// tus datos son las REGLAS de Firestore (también explicadas en el
// README), no el hecho de ocultar esta configuración.
// ============================================================

import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_PROYECTO.firebaseapp.com",
  projectId: "TU_PROYECTO",
  storageBucket: "TU_PROYECTO.appspot.com",
  messagingSenderId: "TU_SENDER_ID",
  appId: "TU_APP_ID",
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
